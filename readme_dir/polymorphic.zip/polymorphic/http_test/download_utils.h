#ifndef _download_utils_
#define _download_utils_

#define ERROR_TYPE_FAILED  -1
#define ERROR_TYPE_SUCCESS  0

#define INVALID_FILELENGTH -1 


#endif